# EE/CS 148B HW 2 Written Responses

## 2.3 End-to-End Benchmarking

### Forward vs. Backward Timings

Run:

```sh
uv run python -m systems.benchmark --model-size small --mode forward
uv run python -m systems.benchmark --model-size small --mode forward-backward
uv run python -m systems.benchmark --model-size medium --mode forward
uv run python -m systems.benchmark --model-size medium --mode forward-backward
uv run python -m systems.benchmark --model-size large --mode forward
uv run python -m systems.benchmark --model-size large --mode forward-backward
```

Fill in the measured means and standard deviations from the script output. The backward pass should take longer than the forward pass because it computes gradients for each differentiable operation and stores/uses activation information; the standard deviation should be small after enough warmup unless the GPU is shared or clocks are changing.

### Warmup

Without warmup, the first measured iterations include one-time overheads such as CUDA context initialization, allocator growth, kernel loading, autotuning, and cache effects, so the mean is usually slower and the variance is larger. One or two warmup steps may still be insufficient because not all kernels or allocation paths have been exercised, while 10 warmup steps should usually stabilize the measurement unless the model is large enough to trigger thermal, clock, or memory-pressure effects.

## 2.4 Nsight Systems

1. The total forward-pass time in Nsight should be close to the Python benchmark when the same region is measured and CUDA synchronization is used; differences come from profiler overhead and from whether warmup/optimizer/loss computation is included.
2. The most expensive forward kernels are typically GEMM/matmul kernels from the attention projections, attention score/value products, FFN layers, and LM head. In forward plus backward, GEMM kernels usually remain dominant, but backward kernels for matrix multiplications and parameter-gradient computations add a larger share.
3. Non-matmul kernels that commonly take non-trivial time include softmax, elementwise activations such as SiLU, masking/fill operations, RMSNorm reductions, residual adds, type casts, and memory movement kernels.
4. In a full AdamW training step, the fraction of time spent in matrix multiplication generally decreases relative to inference because backward and optimizer work add many elementwise kernels, reductions, and parameter update kernels.
5. Softmax has far fewer FLOPs than the attention matrix multiplications, but it can take a noticeable fraction of runtime because it is memory-bandwidth and reduction heavy. The runtime gap is therefore usually smaller than the FLOP gap.

## 2.5 Mixed Precision

### Accumulation Accuracy

The observed values were approximately `10.0001` for FP32 accumulation, `9.9531` for FP16 accumulation, and `10.0021` for accumulating FP16 inputs into FP32. FP16 accumulation drifts noticeably because `0.01` is not represented exactly and repeated additions round in a much lower precision accumulator; FP32 accumulation of FP16 inputs improves the result, but it still reflects the initial FP16 quantization of `0.01`.

### Autocast Dtypes

| Component | dtype under FP16 autocast |
|---|---|
| Model parameters | `torch.float32` |
| Output of `ToyModel.fc1` | `torch.float16` |
| Output of `ToyModel.ln` | `torch.float16` output, with sensitive internal reductions handled in higher precision by autocast/kernel policy |
| Predicted logits | `torch.float16` |
| Loss | usually `torch.float32` |
| Gradients | `torch.float32` parameter gradients |

LayerNorm is sensitive because it squares/sums values to compute mean and variance, and those reductions can underflow or overflow more easily in FP16. BF16 has the same exponent range as FP32, so it is much less prone to overflow/underflow, but many implementations still keep normalization reductions in FP32 because the mantissa is shorter and the cost is small compared with the stability benefit.

### BF16 Benchmarking

Run the benchmark script with and without `--use-bf16` for each model size. BF16 mixed precision should speed up the matmul-heavy parts of the model on Tensor Core GPUs, with the speedup becoming more visible as model size grows; memory use for activations should also decrease, though parameters and optimizer state may still dominate in training.

## 2.6 Memory Profiling

Use:

```sh
uv run python -m systems.benchmark --model-size large --mode forward --use-memory-profiler
uv run python -m systems.benchmark --model-size large --mode train-step --use-memory-profiler
```

The forward-only memory timeline should rise as activations and logits are allocated, then drop after the pass completes. The training-step timeline should show a larger peak through backward because saved activations and gradients coexist, and the optimizer step adds optimizer-state allocations.

| Context length | Forward peak memory | Full training-step peak memory |
|---:|---:|---:|
| 32 | fill from memory profiler | fill from memory profiler |
| 64 | fill from memory profiler | fill from memory profiler |
| 128 | fill from memory profiler | fill from memory profiler |
| 256 | fill from memory profiler | fill from memory profiler |

BF16 should reduce activation memory substantially, but the full training-step reduction may be smaller if FP32 parameters, gradients, or optimizer states dominate. For the large model residual stream at the reference settings, the tensor has shape `(batch, context, d_model) = (4, 128, 1024)`, so its FP32 size is `4 * 128 * 1024 * 4 = 2,097,152` bytes, or `2.0 MiB`.

## 2.7 Attention Profiling

Run:

```sh
uv run python -m systems.attention_benchmark
```

| Head dim | Sequence length | Forward mean | Backward mean | Memory before backward | Status |
|---:|---:|---:|---:|---:|---|
| 16 | 64 | fill from script | fill from script | fill from script | fill from script |
| 16 | 128 | fill from script | fill from script | fill from script | fill from script |
| 16 | 256 | fill from script | fill from script | fill from script | fill from script |
| 16 | 512 | fill from script | fill from script | fill from script | fill from script |
| 16 | 1024 | fill from script | fill from script | fill from script | fill from script |
| 32 | 64 | fill from script | fill from script | fill from script | fill from script |
| 32 | 128 | fill from script | fill from script | fill from script | fill from script |
| 32 | 256 | fill from script | fill from script | fill from script | fill from script |
| 32 | 512 | fill from script | fill from script | fill from script | fill from script |
| 32 | 1024 | fill from script | fill from script | fill from script | fill from script |
| 64 | 64 | fill from script | fill from script | fill from script | fill from script |
| 64 | 128 | fill from script | fill from script | fill from script | fill from script |
| 64 | 256 | fill from script | fill from script | fill from script | fill from script |
| 64 | 512 | fill from script | fill from script | fill from script | fill from script |
| 64 | 1024 | fill from script | fill from script | fill from script | fill from script |
| 128 | 64 | fill from script | fill from script | fill from script | fill from script |
| 128 | 128 | fill from script | fill from script | fill from script | fill from script |
| 128 | 256 | fill from script | fill from script | fill from script | fill from script |
| 128 | 512 | fill from script | fill from script | fill from script | fill from script |
| 128 | 1024 | fill from script | fill from script | fill from script | fill from script |

The dominant saved tensor in naive attention is the attention score/probability matrix of shape `(batch, seq_len, seq_len)` for each head, so memory grows quadratically with sequence length. To eliminate this cost, use a memory-efficient attention implementation such as FlashAttention or PyTorch scaled-dot-product attention with a fused backend that recomputes/tiles attention instead of materializing the full matrix.

## 2.8 Torch Compile

Run:

```sh
uv run python -m systems.attention_benchmark --compile-attention
uv run python -m systems.benchmark --model-size small --compile-model
uv run python -m systems.benchmark --model-size medium --compile-model
uv run python -m systems.benchmark --model-size large --compile-model
```

Compiled attention should often reduce overhead by fusing pointwise operations and improving kernel selection, although the first iteration includes compilation time and should not be included in the timing. Whole-model compilation can help most for repeated runs with static shapes, but it may be less useful if the model is already dominated by highly optimized library GEMMs.

## 3.2 GSM8K Baselines

The direct baseline should be reported with format reward, answer reward, and total reward. Failures usually come from malformed `<answer>` tags, extracting a reasoning string instead of a final answer, or numerically equivalent answers that the grader does not normalize.

CoT prompting should outperform direct prompting because the model gets space to decompose the arithmetic before giving a final tagged answer. The reasoning traces are usually aligned with the final answer when the sample is correct, but incorrect samples may contain arithmetic slips or a final answer that does not follow from the written trace.

With self-consistency at `K=5`, performance should improve over a single CoT sample if the model's correct answer has the highest modal probability. Ties should be uncommon on easy problems but can appear when the model is uncertain; prediction distributions are often fairly peaked for easy arithmetic and multi-modal for harder word problems.

## 3.5 GRPO

The GRPO train loop should show validation answer reward increasing over training if rollouts are well-formed and the reward function is not too sparse. Example rollouts should gradually contain more valid `<answer>...</answer>` responses and more correct arithmetic.

When comparing standard-deviation normalization against mean-only centering, std normalization can produce larger updates for groups with very low reward variance, which may increase gradient norm spikes. Mean-only centering is often more stable because it avoids upweighting nearly all-correct or all-wrong groups, though the best validation curve should be determined from the 50-step runs.
